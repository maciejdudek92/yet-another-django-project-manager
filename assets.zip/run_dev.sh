#!/bin/sh
django_path={{django_path}}
next_js_path={{next_js_path}}

./dev --django $django_path --nextjs $next_js_path