


urlpatterns = []
